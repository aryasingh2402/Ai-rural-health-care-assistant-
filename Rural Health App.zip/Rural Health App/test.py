# --- 1. IMPORT SDK ---
# Imports the official Google Generative AI library
import google.generativeai as genai

# --- 2. AUTHENTICATION ---
# Configures the SDK with your specific credentials. 
# (Remember: NEVER hardcode your real key if uploading to GitHub. Use environment variables later!)
genai.configure(api_key="AIzaSyDVe8Q2DlmFaOC2comS0aoKu3QSZTJt_Lc")

print("Fetching available models for your API key...\n")

try:
    # --- 3. FETCH & ITERATE ---
    # genai.list_models() makes an API call to Google and returns a list of EVERY 
    # model your account has access to (including embedding models, vision models, etc.)
    for model in genai.list_models():
        
        # --- 4. FILTERING ---
        # We don't want all models. We ONLY want models that can act as a chatbot 
        # and generate text. In Google's architecture, this specific capability 
        # is called 'generateContent'.
        if 'generateContent' in model.supported_generation_methods:
            
            # --- 5. OUTPUT ---
            # If the model passes the filter, print its exact system name 
            # (e.g., 'models/gemini-1.5-flash'). This is the exact string you need 
            # to copy and paste into your main app.py file!
            print(model.name)

except Exception as e:
    # Catch any connection errors or invalid API key issues
    print(f"Error listing models: {e}")