# --- 1. IMPORTING LIBRARIES ---
import streamlit as st                 # The frontend web framework
import speech_recognition as sr        # Google's Speech-to-Text engine
import google.generativeai as genai    # Google's Gemini LLM SDK
from datetime import datetime          # Used to generate timestamps for new chat names
import io                              # Handles raw bytes in memory (for the audio fix)
import time                            # Tracks current time for the rate limit countdown
import re                              # Regular Expressions to extract wait times from errors

# Add your NEW API key here:
# (Reminder: Delete this key from Google AI Studio if it is exposed online!)
MY_GEMINI_KEY = "AIzaSyDVe8Q2DlmFaOC2comS0aoKu3QSZTJt_Lc"

# --- 2. CONFIGURATION & PROMPTS ---
# Dictionary mapping human-readable languages to BCP-47 codes for the speech recognizer
VOICE_LANGUAGES = {
    "English": "en-US",
    "Hindi (हिंदी)": "hi-IN",
    "Russian (Русский)": "ru-RU",
    "Tamil (தமிழ்)": "ta-IN",
    "Spanish (Español)": "es-ES",
    "French (Français)": "fr-FR"
}

# The strict instructions injected into the AI's memory before it speaks to the user.
SYSTEM_PROMPT = """
You are an AI Rural Health Assistant for a college project. Follow these rules:
1. EMERGENCY FIRST: If symptoms indicate an emergency (chest pain, severe bleeding, stroke, breathing trouble), instantly output a bold 🚨 EMERGENCY ALERT and tell them to go to a hospital.
2. NEW SYMPTOMS (CARE PLAN): When a user reports a NEW symptom, provide a care plan exactly like this:
   💊 **Medicines (Over-the-Counter):** [Standard OTC meds only]
   🌿 **Home Remedies:** [Traditional/home care]
   🍲 **Food Suggestions:** [What to eat/avoid]
3. FOLLOW-UP QUESTIONS: If the user asks a follow-up question (e.g., "How many times a day?", "Can I eat this?"), answer ONLY their specific question naturally and directly. DO NOT output the 💊🌿🍲 format for simple follow-up questions.
4. LANGUAGE MATCH: Always reply in the exact language the user typed or spoke in.
5. DISCLAIMER: End initial care plans with: "\n---\n*Disclaimer: Please Make Sure to Consult a Physician or Doctor.*"
"""

# --- 3. INITIALIZE AI ENGINE ---
# Authenticate and set up the specific model we want to use
genai.configure(api_key=MY_GEMINI_KEY)
model = genai.GenerativeModel('gemini-flash-lite-latest', system_instruction=SYSTEM_PROMPT)

# --- 4. SESSION STATE MANAGEMENT (The App's Memory) ---
# Streamlit reruns this entire script on every interaction. We use st.session_state 
# (like an HttpSession in Spring Boot) to keep data alive between those reruns.

# Create a dictionary to hold multiple separate chat histories
if "all_chats" not in st.session_state:
    st.session_state.all_chats = {} 

# Track which chat the user is currently looking at
if "current_chat_id" not in st.session_state:
    st.session_state.current_chat_id = None

# Variables specifically used to fix the audio widget crash and track API rate limits
if "audio_key" not in st.session_state:
    st.session_state.audio_key = 0
if "raw_audio_bytes" not in st.session_state:
    st.session_state.raw_audio_bytes = None
if "api_unlock_time" not in st.session_state:
    st.session_state.api_unlock_time = 0

# Helper function to create a brand new chat instance
def start_new_chat():
    """Creates a new chat session and sets it as active."""
    # Create a dynamic name like 'Chat 1 - 14:30'
    chat_id = f"Chat {len(st.session_state.all_chats) + 1} - {datetime.now().strftime('%H:%M')}"
    
    # Store a fresh UI message list and a fresh Gemini memory instance in the dictionary
    st.session_state.all_chats[chat_id] = {
        "messages": [],
        "gemini_session": model.start_chat(history=[])
    }
    # Immediately switch the view to this new chat
    st.session_state.current_chat_id = chat_id

# If the app just booted up for the first time, initialize Chat 1
if not st.session_state.all_chats:
    start_new_chat()

# Create pointer variables to make accessing the currently active chat easier
active_chat = st.session_state.all_chats[st.session_state.current_chat_id]
active_messages = active_chat["messages"]
active_gemini = active_chat["gemini_session"]


# --- 5. BUILDING THE USER INTERFACE (UI) ---
st.set_page_config(page_title="AI Health Chat", page_icon="🏥", layout="centered")
st.title("🏥 AI Medical Assistant")

# Build the Sidebar (Menu)
with st.sidebar:
    # Button to trigger the start_new_chat logic
    if st.button("➕ New Chat", use_container_width=True):
        start_new_chat()
        st.rerun() # Forces the page to instantly refresh to show the blank chat
        
    st.divider()
    
    # Render all saved chats as clickable buttons in reverse order (newest at top)
    st.header("🗂️ Previous Chats")
    for chat_id in reversed(list(st.session_state.all_chats.keys())):
        if st.button(chat_id, use_container_width=True):
            st.session_state.current_chat_id = chat_id # Switch active chat
            st.rerun()
            
    st.divider()
    
    # Voice Input Section
    st.header("🎙️ Voice Input")
    selected_voice_lang = st.selectbox("Select spoken language:", list(VOICE_LANGUAGES.keys()))
    speech_code = VOICE_LANGUAGES[selected_voice_lang]
    
    # Render the audio widget. We attach a dynamic key (like audio_0, audio_1)
    audio_value = st.audio_input("Record your symptoms", key=f"audio_{st.session_state.audio_key}")

# --- 6. ASYNCHRONOUS AUDIO PROCESSING HACK ---
# If audio was recorded, instantly grab the bytes, destroy the old widget by changing its key,
# and refresh the page. This prevents the widget from showing a timeout error.
if audio_value:
    st.session_state.raw_audio_bytes = audio_value.getvalue()
    st.session_state.audio_key += 1
    st.rerun() 

# --- 7. RENDERING CHAT HISTORY ---
# Loop through the currently active chat's memory and draw the chat bubbles on screen
for message in active_messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# --- 8. INPUT RESOLUTION (Voice vs. Text) ---
text_input = st.chat_input("Type your symptoms or ask a follow-up question...")
user_prompt = None

# If we have raw audio bytes waiting from the instantaneous refresh above, process them now.
if st.session_state.raw_audio_bytes:
    with st.chat_message("user"):
        with st.spinner("🎙️ Transcribing voice..."):
            r = sr.Recognizer()
            try:
                # Package the raw bytes into a virtual file so the recognizer can read it
                with sr.AudioFile(io.BytesIO(st.session_state.raw_audio_bytes)) as source:
                    audio_data = r.record(source)
                    # Translate speech to text
                    user_prompt = r.recognize_google(audio_data, language=speech_code)
                    st.markdown(user_prompt) # Show the transcribed text in the UI
            except Exception as e:
                st.error("Could not process audio. Please try speaking clearly.")
    
    # Clear the bytes out of memory so it doesn't get stuck in a loop
    st.session_state.raw_audio_bytes = None

    # Save the transcribed text to the UI memory
    if user_prompt:
        active_messages.append({"role": "user", "content": user_prompt})

# If no audio was recorded, check if the user typed text instead
elif text_input:
    user_prompt = text_input
    active_messages.append({"role": "user", "content": user_prompt})
    with st.chat_message("user"):
        st.markdown(user_prompt)

# --- 9. GENERATE AI RESPONSE & RATE LIMITING ---
if user_prompt:
    with st.chat_message("assistant"):
        
        # Step 9A: Check the Rate Limit Timer
        current_time = time.time()
        # If the current clock time is still behind the unlock time, block the request
        if st.session_state.api_unlock_time > current_time:
            remaining_seconds = int(st.session_state.api_unlock_time - current_time)
            st.warning(f"⏳ Rate Limit Active. Please wait {remaining_seconds} seconds before asking again.")
        else:
            
            # Step 9B: Fetch Response
            with st.spinner("Thinking..."):
                try:
                    # Send text to Gemini and wait for the response
                    response = active_gemini.send_message(user_prompt)
                    st.markdown(response.text)
                    # Save the AI's response to the UI memory
                    active_messages.append({"role": "assistant", "content": response.text})
                
                # Step 9C: Handle 429 Quota Errors
                except Exception as e:
                    error_msg = str(e)
                    if "429" in error_msg or "Quota exceeded" in error_msg:
                        wait_time = 60 # Default to 60s if we can't read the error string
                        
                        # Use Regex to hunt for the exact wait time in the error text
                        match = re.search(r"retry in (\d+\.?\d*)s", error_msg)
                        if match:
                            wait_time = float(match.group(1))
                        else:
                            # Fallback regex just in case Google changes their error format slightly
                            match_fallback = re.search(r"seconds:\s*(\d+)", error_msg)
                            if match_fallback:
                                wait_time = float(match_fallback.group(1))
                        
                        # Set the unlock time in the future
                        st.session_state.api_unlock_time = time.time() + wait_time
                        st.warning(f"⏳ Quota exceeded. Please wait {int(wait_time)} seconds and try asking again.")
                    else:
                        # If it's a different kind of error (like no internet), print it normally
                        st.error(f"API Error: {error_msg}")
